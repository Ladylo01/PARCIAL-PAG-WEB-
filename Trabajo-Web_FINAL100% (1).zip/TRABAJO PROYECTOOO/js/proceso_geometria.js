

var divtabla=document.getElementById('cuadro')
var i=1;
var botonenviar=document.getElementById('btnagregar')
var botoneditar=document.getElementById('btneditar')
botoneditar.disabled = true;


var infoForm={};


function procesar() {
var precio=document.getElementById('txtprecio').value
var cantidad=document.getElementById('txtcantidad').value
var producto=document.getElementById("txtproducto").value
var tipo=document.getElementById("selector").value


if(precio=="" || cantidad==""){ 
  alert("debe ingresar la informacion en todos los campos")
}else{
    var total= parseFloat(precio)*parseFloat(cantidad);
    
 





    var tabla = document.getElementById("mitabla");
    var nuevaFila = tabla.insertRow(tabla.lenght);

    cell1 = nuevaFila.insertCell(0);
    cell1.innerHTML = i++;

    cell2 = nuevaFila.insertCell(1);
    cell2.innerHTML = producto;
    
    cell3 = nuevaFila.insertCell(2);
    cell3.innerHTML = tipo;

    cell4 = nuevaFila.insertCell(3);
    cell4.innerHTML = cantidad;

    cell5 = nuevaFila.insertCell(4);
    cell5.innerHTML = "$"+precio;

    cell6 = nuevaFila.insertCell(5);
    cell6.innerHTML = "$"+total;

    cell6 = nuevaFila.insertCell(6);
    cell6.innerHTML = '<a class="btn btn-warning mx-S " onClick="onEdit(this)">Edit</a> <a class= "btn btn-danger " onClick="onDelete(this)">Delete</a>' ;
     
    


    document.getElementById("formulario").reset();
    divtabla.style.display='';

    }

    }


    function onEdit(td){
        btneditar.disabled = false;
        btnagregar.disabled = true;
        selectedRow = td.parentElement.parentElement;
          
        precio = selectedRow.cells[5].innerHTML;
        cantidad = selectedRow.cells[4].innerHTML;
        producto= selectedRow.cells[2].innerHTML;
        tipo = selectedRow.cells[3].innerHTML;
       
    }

    function actualizarfila() {
        precio=document.getElementById('txtprecio').value
        cantidad=document.getElementById('txtcantidad').value
        if(precio=="" || cantidad==""){;
            alert("debe ingresar la informacion en todos los campos")
        }else{
             
             precio = document.getElementById("txtprecio").value
             cantidad =document.getElementById("txtcantidad").value
             producto= document.getElementById("txtproducto").value
             tipo = document.getElementById("selector").value
             
             total= parseFloat(precio)*parseFloat(cantidad);
             

             selectedRow.cells[1].innerHTML = producto;
             selectedRow.cells[2].innerHTML = tipo;
             selectedRow.cells[3].innerHTML = cantidad;
             selectedRow.cells[4].innerHTML = precio;
             selectedRow.cells[5].innerHTML = total;
            
             btneditar.disabled = true;
             btnagregar.disabled = false;
             alert("Fila editada exitosamente");
             document.getElementById("miForm").reset();
        }             
    }





    function onDelete(td){

        if (confirm('Estas seguro de esto? si lo borras perderas la informacion')){

            row = td.parentElement.parentElement;
            document.getElementById("mitabla").deleteRow(row.rowIndex);


            var num = document.getElementById('mitabla').rows.length;

            if(num==1){
                divtabla.style.display='none';
            }
        }
id

    
}
    
