document.getElementById('downloadexcel4').addEventListener('click', function() {
    var table2excel = new Table2Excel();
    table2excel.export(document.querySelectorAll("#mitabla4"));
  });




var divtabla = document.getElementById('cuadro4')
var i=1
var btnenviar=document.getElementById('btnenviar')
var btneditar=document.getElementById('btneditar')

btneditar.disabled = true;

var infoForm={}

function registrarpedido() {
    var metodo=document.getElementById('metodo').value
    var nombre=document.getElementById('nombre').value
    var numero=document.getElementById('numero').value
    var expiracion=document.getElementById('expiracion').value
    var cvv=document.getElementById('cvv').value

    if(metodo=="" || nombre=="" || numero=="" || expiracion=="" || cvv==""){
        swal('Oops...','Debe llenar todos los campos del formulario','error');
    }else{
        swal('¡Listo!','Gracias por hacer su compra en nuestra página!','success');

        infoForm ["metodo"]= metodo;
        infoForm ["nombre"]= nombre;
        infoForm ["numero"]= numero;
        infoForm ["expiracion"]= expiracion;
        infoForm ["cvv"]= cvv;

        var tabla = document.getElementById("mitabla4");
        var nuevaFila = tabla.insertRow(tabla.length);

        cell1 = nuevaFila.insertCell(0);
        cell1.innerHTML = infoForm.metodo;

        cell2 = nuevaFila.insertCell(1);
        cell2.innerHTML = infoForm.nombre;

        cell3 = nuevaFila.insertCell(2);
        cell3.innerHTML = infoForm.numero;

        cell4 = nuevaFila.insertCell(3);
        cell4.innerHTML = infoForm.expiracion;

        cell5 = nuevaFila.insertCell(4);
        cell5.innerHTML = infoForm.cvv;

        cell6 = nuevaFila.insertCell(5);
        cell6.innerHTML = '<a class="btn btn-warning mx-S " onClick="onEdit(this)"><i class="bi bi-pencil-fill"></i></a> <a class= "btn btn-danger " onClick="onDelete(this)"><i class="bi bi-trash-fill"></i></a>' ;

        document.getElementById("miForm4").reset();
        divtabla.style.display='';
    }
}

    function onEdit(td){
        btneditar.disabled = false;
        btnenviar.disabled = true;
        selectedRow = td.parentElement.parentElement;
        document.getElementById("metodo").value = selectedRow.cells[0].innerHTML;
        document.getElementById("nombre").value = selectedRow.cells[1].innerHTML;
        document.getElementById("numero").value = selectedRow.cells[2].innerHTML;
        document.getElementById("expiracion").value = selectedRow.cells[3].innerHTML;
        document.getElementById("cvv").value = selectedRow.cells[4].innerHTML;
    }

    function actualizarfila4() {

        metodo=document.getElementById('metodo').value
        nombre=document.getElementById('nombre').value
        numero=document.getElementById('numero').value
        expiracion=document.getElementById('expiracion').value
        cvv=document.getElementById('cvv').value

        if(metodo=="" || nombre=="" || numero=="" || expiracion=="" || cvv==""){
            swal('Oops...','Debe ingresar la información en todos los campos','error');
        }else{
            swal('¡Bien!','La fila ha sido editada exitosamente','success');

            infoForm ["metodo"]= metodo;
            infoForm ["nombre"]= nombre;
            infoForm ["numero"]= numero;
            infoForm ["expiracion"]= expiracion;
            infoForm ["cvv"]= cvv;

            selectedRow.cells[0].innerHTML = infoForm.metodo;
            selectedRow.cells[1].innerHTML = infoForm.nombre;
            selectedRow.cells[2].innerHTML = infoForm.numero;
            selectedRow.cells[3].innerHTML = infoForm.expiracion;
            selectedRow.cells[4].innerHTML = infoForm.cvv;

            btneditar.disabled = true;
            btnenviar.disabled = false;
            document.getElementById("miForm4").reset();
        }

    }

    function onDelete(td){

        if (confirm('Estas seguro de esto? Si lo borras perderas la información')){
    
          row = td.parentElement.parentElement;
          document.getElementById("mitabla4").deleteRow(row.rowIndex);
    
          var num = document.getElementById('mitabla4').rows.length;
    
          if(num==1){
            divtabla.style.display='none';
          }
        }
      }